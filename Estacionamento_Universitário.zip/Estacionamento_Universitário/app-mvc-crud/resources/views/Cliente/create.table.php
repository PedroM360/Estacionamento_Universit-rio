<h1>Adicionar Cliente</h1>
<form action="{{ route('clientes.store') }}" method="POST">
    @csrf
    Nome: <input type="text" name="nome"><br>
    Email: <input type="text" name="email"><br>
    <button type="submit">Salvar</button>
</form>
