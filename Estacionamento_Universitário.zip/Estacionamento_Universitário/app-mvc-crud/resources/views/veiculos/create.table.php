<h1>Adicionar Veiculo</h1>
<form action="{{ route('clientes.store') }}" method="POST">
    @csrf
    User: <input type="text" name="user"><br>
    Matricula: <input type="text" name="matricula"><br>
    <button type="submit">Salvar</button>
</form>
