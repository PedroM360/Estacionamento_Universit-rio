<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MovimentacaoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $movimentacao = Movimentacao::all();
        return view('movimentacao.index', compact('movimentacao'));
    }
    
    public function create()
    {
        return view('movimentacao.create');
    }
    
    public function store(Request $request)
    {
        Movimentacao::create($request->all());
        return redirect()->route('movimentacao.index');
    }
    
    public function edit($id)
    {
        $movimentacaos = Movimentacao::find($id);
        return view('movimentacao.edit', compact('movimentacaos'));
    }
    
    public function update(Request $request, $id)
    {
        $movimentacaos = Movimentacao::find($id);
        $movimentacaos->update($request->all());
        return redirect()->route('movimentacao.index');
    }
    
    public function destroy($id)
    {
        Movimentacao::destroy($id);
        return redirect()->route('movimentacao.index');
    }
    
}
